t = list(map(lambda x: list(map(int, x.split(":"))),open("input.txt").read().split("\n")))

print("2. feladat")
print("Az 1. sorban szereplő számok maximuma:", max(t[0]))

print("3. feladat")
k = (i**2 for i in t[1] if i % 2 == 1)
print("A  2. sorban szereplő páratlan számok négyzeteinek összege:", sum(k))

print("4. feladat")
k = (i for i in t[2] if i<21)
szorzat = 1
for i in k:
    szorzat *= i
print("A 3. sorban szereplő 21-nél kisebb számok szorzatának nagyságrendje:", f'10^{len(str(szorzat))-1}')

print("5. feladat")
k = list(i for i in t[3] if i % 3 == 0)
print(f'A 4. sorban szereplő hárommal osztható számok számtani közepe: {sum(k)/len(k):0.2f}')

print("6. feladat")
k = list(map(lambda x: x,sorted(t[4])[-10:]))
print("Az 5. sorban szereplő 10 legnagyobb szám összege:", sum(k))

print("7. feladat")
from math import sqrt as m
t5 = sorted(list(filter(lambda x: m(x) == int(m(x)), sum(t, []))))
print("Az inputban szereplő összes szám közül a négyzetszámok minimuma:", min(t5))